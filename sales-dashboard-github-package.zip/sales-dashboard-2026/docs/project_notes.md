# Project Notes

## Workbook sheets

- `Data`: underlying sales records and calculated fields.
- `Analyse`: supporting summary tables and pivot-style calculations.
- `Dashboard`: interactive visual reporting page.

## Reproducibility note

The original Excel workbook is included without modification so that its dashboard, formulas, pivot tables, and interactive elements remain available in the source file.

The CSV file is an export of the `Data` worksheet and is intended to make the dataset easier to inspect or reuse in other analytics tools.
