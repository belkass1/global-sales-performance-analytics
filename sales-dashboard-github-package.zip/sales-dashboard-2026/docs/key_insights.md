# Key Insights — Sales Dashboard 2026

## Executive summary

The dataset contains **2,707 records** from **2026-01-01 to 2026-12-30**.

- Total revenue: **$645,223.18**
- Gross profit: **$296,384.25**
- Gross margin: **45.9%**
- Units sold: **6,698**
- Average revenue per record: **$238.35**

## Revenue by month

- January: $39,091.82 revenue; $17,596.94 gross profit
- February: $35,647.72 revenue; $16,561.51 gross profit
- March: $44,696.90 revenue; $21,465.04 gross profit
- April: $54,688.64 revenue; $25,283.65 gross profit
- May: $58,235.18 revenue; $27,301.53 gross profit
- June: $69,504.34 revenue; $31,109.93 gross profit
- July: $66,442.24 revenue; $31,035.09 gross profit
- August: $57,609.04 revenue; $27,126.76 gross profit
- September: $53,609.28 revenue; $25,001.06 gross profit
- October: $49,147.53 revenue; $22,793.03 gross profit
- November: $65,523.64 revenue; $28,666.87 gross profit
- December: $51,026.85 revenue; $22,442.84 gross profit

The highest monthly revenue was recorded in **June**, with **$69,504.34**.

## Top countries by revenue

- United Kingdom: $74,427.37
- Germany: $70,034.11
- France: $55,102.05
- Italy: $50,319.47
- Spain: $46,624.59

## Revenue by product category

- Camping: $198,505.13
- Hiking: $179,959.14
- Travel: $123,724.49
- Cycling: $87,481.99
- Fitness: $55,552.43

## Top products by units sold

- Trail Boots: 449 units
- Summit Backpack 45L: 447 units
- Compact Sleeping Bag: 433 units
- Hiking Daypack 20L: 396 units
- Trail Bike Light: 392 units

## Interpretation guidelines

These observations describe the dataset but do not, by themselves, explain the causes behind the results. Further analysis could investigate:

- Sales-channel contribution
- Customer-type performance
- Discount impact on gross margin
- Regional differences in product mix
- Month-over-month growth rates
- Outlier transactions and data quality
