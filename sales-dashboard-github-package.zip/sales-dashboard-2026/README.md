# Sales Dashboard 2026 — Excel Data Analytics Project

![Dashboard preview](assets/dashboard_preview.png)

## Overview

This repository presents an interactive **Sales Dashboard for 2026**, built in Microsoft Excel from a structured sales dataset.

The project demonstrates practical data-analyst skills, including:

- Data preparation and structured data organization
- KPI definition and business reporting
- Pivot-table-based analysis
- Revenue and gross-profit trend analysis
- Geographic performance analysis
- Product-category and top-product analysis
- Interactive dashboard design using filters/slicers

## Business questions addressed

1. What are the total sales, gross profit, units sold, and average revenue per record?
2. How do revenue and gross profit evolve throughout the year?
3. Which countries generate the highest revenue?
4. Which product categories contribute most to revenue?
5. Which products have the highest sales volume?

## Key figures from the workbook

| KPI | Value |
|---|---:|
| Total revenue | $645,223.18 |
| Gross profit | $296,384.25 |
| Units sold | 6,698 |
| Average revenue per record* | $238.35 |
| Gross margin | 45.9% |
| Number of records | 2,707 |
| Data coverage | 2026-01-01 to 2026-12-30 |

> *The workbook displays the $238.35 metric as “Avg. Price”. Based on the source data, this value corresponds to average revenue per record (`Revenue ÷ number of records`), so it is described more precisely here.

## Selected findings

- **Highest-revenue month:** June ($69,504.34).
- **Leading country by revenue:** United Kingdom ($74,427.37).
- **Leading product category:** Camping ($198,505.13).
- **Top product by units sold:** Trail Boots (449 units).

These findings are descriptive and are intended to support further business investigation.

## Repository structure

```text
sales-dashboard-2026/
├── README.md
├── README_FR.md
├── .gitignore
├── assets/
│   └── dashboard_preview.png
├── data/
│   ├── Interactive Excel Sales Dashboard.xlsx
│   └── sales_data.csv
└── docs/
    ├── data_dictionary.md
    └── key_insights.md
```

## How to use the project

1. Download or clone the repository.
2. Open `data/Interactive Excel Sales Dashboard.xlsx` in Microsoft Excel.
3. Go to the `Dashboard` sheet.
4. Use the available filters/slicers to explore the results.
5. Review the `Data` and `Analyse` sheets to understand the source data and supporting calculations.

## Tools and techniques

- Microsoft Excel
- Pivot tables and `GETPIVOTDATA`
- KPI cards
- Interactive filters/slicers
- Data aggregation and business storytelling
- Geographic and time-series analysis

## Data notes

- The dataset contains 2,707 records covering 2026.
- Monetary values are expressed in USD.
- The repository includes both the original Excel workbook and a CSV export of the `Data` sheet.
- The dataset's licensing/provenance was not specified; the files are included for portfolio demonstration purposes.

## Author

**Data Analytics Portfolio Project**

This project is designed to demonstrate the ability to transform structured sales data into a clear, interactive business dashboard.
