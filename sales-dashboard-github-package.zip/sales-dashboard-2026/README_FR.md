# Sales Dashboard 2026 — Projet d’analyse de données sur Excel

![Aperçu du dashboard](assets/dashboard_preview.png)

## Présentation

Ce dépôt présente un **dashboard commercial 2026 interactif**, réalisé sur Microsoft Excel à partir d’un jeu de données de ventes structuré.

Le projet met en avant plusieurs compétences de data analyst :

- Organisation et préparation des données
- Définition et suivi des KPI
- Analyse à l’aide de tableaux croisés dynamiques
- Analyse de l’évolution du chiffre d’affaires et du résultat brut
- Analyse géographique
- Analyse par catégorie de produits et par produit
- Conception d’un dashboard interactif avec filtres/segments

## Questions métier traitées

1. Quel est le chiffre d’affaires total, le résultat brut et le volume vendu ?
2. Comment évoluent le chiffre d’affaires et le résultat brut au fil des mois ?
3. Quels pays génèrent le plus de chiffre d’affaires ?
4. Quelles catégories de produits contribuent le plus au chiffre d’affaires ?
5. Quels produits affichent le plus grand volume de ventes ?

## Chiffres clés

| KPI | Valeur |
|---|---:|
| Chiffre d’affaires total | $645,223.18 |
| Résultat brut | $296,384.25 |
| Unités vendues | 6,698 |
| Revenu moyen par ligne* | $238.35 |
| Marge brute | 45.9% |
| Nombre de lignes | 2,707 |
| Période couverte | du 2026-01-01 au 2026-12-30 |

> *Le fichier Excel affiche la valeur de 238,35 sous l’intitulé « Avg. Price ». D’après les données sources, cette valeur correspond au revenu moyen par ligne (`Revenue ÷ nombre de lignes`).

## Quelques constats

- **Mois avec le chiffre d’affaires le plus élevé :** June ($69,504.34).
- **Pays générant le plus de chiffre d’affaires :** United Kingdom ($74,427.37).
- **Catégorie principale :** Camping ($198,505.13).
- **Produit avec le plus grand volume vendu :** Trail Boots (449 unités).

## Structure du dépôt

```text
sales-dashboard-2026/
├── README.md
├── README_FR.md
├── .gitignore
├── assets/
│   └── dashboard_preview.png
├── data/
│   ├── Interactive Excel Sales Dashboard.xlsx
│   └── sales_data.csv
└── docs/
    ├── data_dictionary.md
    └── key_insights.md
```

## Utilisation

1. Téléchargez ou clonez le dépôt.
2. Ouvrez `data/Interactive Excel Sales Dashboard.xlsx` dans Microsoft Excel.
3. Accédez à la feuille `Dashboard`.
4. Utilisez les filtres/segments pour explorer les résultats.
5. Consultez les feuilles `Data` et `Analyse` pour comprendre les données et les calculs.

## Outils et techniques

- Microsoft Excel
- Tableaux croisés dynamiques et `GETPIVOTDATA`
- Cartes KPI
- Filtres et segments interactifs
- Agrégation de données
- Data storytelling

## Notes sur les données

- Le jeu de données contient 2 707 lignes couvrant l’année 2026.
- Les montants sont exprimés en USD.
- Le dépôt contient le fichier Excel original ainsi qu’une exportation CSV de la feuille `Data`.
- La provenance et la licence du jeu de données n’ont pas été précisées ; les fichiers sont inclus à des fins de démonstration dans un portfolio.

## Auteur

**Projet de portfolio — Data Analytics**
